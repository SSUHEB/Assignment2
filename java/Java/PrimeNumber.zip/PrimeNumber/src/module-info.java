/**
 * 
 */
/**
 * @author pravilal
 *
 */
module PrimeNumber {
}